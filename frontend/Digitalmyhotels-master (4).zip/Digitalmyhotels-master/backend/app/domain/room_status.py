"""Room status state machine.

Single source of truth for room lifecycle transitions. Services must go
through `assert_transition` rather than assigning statuses directly.
"""

from __future__ import annotations

from enum import StrEnum

from app.core.errors import ConflictError


class RoomStatus(StrEnum):
    AVAILABLE = "available"
    RESERVED = "reserved"
    OCCUPIED = "occupied"
    CLEANING_REQUIRED = "cleaning_required"
    CLEANING_IN_PROGRESS = "cleaning_in_progress"
    CLEAN_READY = "clean_ready"
    INSPECTION_REQUIRED = "inspection_required"
    MAINTENANCE = "maintenance"
    OUT_OF_SERVICE = "out_of_service"


# from -> allowed targets
TRANSITIONS: dict[RoomStatus, frozenset[RoomStatus]] = {
    RoomStatus.AVAILABLE: frozenset(
        {
            RoomStatus.RESERVED,
            RoomStatus.OCCUPIED,
            RoomStatus.MAINTENANCE,
            RoomStatus.OUT_OF_SERVICE,
        }
    ),
    RoomStatus.RESERVED: frozenset(
        {RoomStatus.OCCUPIED, RoomStatus.AVAILABLE, RoomStatus.MAINTENANCE}
    ),
    RoomStatus.OCCUPIED: frozenset(
        # Room transfer frees an occupied room straight to cleaning.
        {RoomStatus.CLEANING_REQUIRED}
    ),
    RoomStatus.CLEANING_REQUIRED: frozenset(
        {
            RoomStatus.CLEANING_IN_PROGRESS,
            RoomStatus.MAINTENANCE,
            RoomStatus.OUT_OF_SERVICE,
            # Stayover clean: guest still in-house → restore Occupied.
            RoomStatus.OCCUPIED,
        }
    ),
    RoomStatus.CLEANING_IN_PROGRESS: frozenset(
        {
            RoomStatus.CLEAN_READY,
            RoomStatus.INSPECTION_REQUIRED,
            RoomStatus.MAINTENANCE,
            RoomStatus.OCCUPIED,
        }
    ),
    RoomStatus.CLEAN_READY: frozenset(
        {RoomStatus.AVAILABLE, RoomStatus.INSPECTION_REQUIRED, RoomStatus.OCCUPIED}
    ),
    RoomStatus.INSPECTION_REQUIRED: frozenset(
        {RoomStatus.AVAILABLE, RoomStatus.CLEANING_REQUIRED, RoomStatus.MAINTENANCE}
    ),
    RoomStatus.MAINTENANCE: frozenset(
        {RoomStatus.AVAILABLE, RoomStatus.CLEANING_REQUIRED, RoomStatus.OUT_OF_SERVICE}
    ),
    RoomStatus.OUT_OF_SERVICE: frozenset(
        {RoomStatus.AVAILABLE, RoomStatus.MAINTENANCE}
    ),
}

# Statuses in which a room can be allocated to a new booking/check-in.
ALLOCATABLE = frozenset({RoomStatus.AVAILABLE, RoomStatus.CLEAN_READY})


def can_transition(current: RoomStatus | str, target: RoomStatus | str) -> bool:
    cur = RoomStatus(current)
    tgt = RoomStatus(target)
    if cur == tgt:
        return True
    return tgt in TRANSITIONS.get(cur, frozenset())


# Human-friendly labels for error messages (client: raw enums like
# 'cleaning_required' in error toasts were confusing to front-desk staff).
STATUS_LABELS: dict[RoomStatus, str] = {
    RoomStatus.AVAILABLE: "Available",
    RoomStatus.RESERVED: "Reserved",
    RoomStatus.OCCUPIED: "Occupied",
    RoomStatus.CLEANING_REQUIRED: "Cleaning Required",
    RoomStatus.CLEANING_IN_PROGRESS: "Cleaning In Progress",
    RoomStatus.CLEAN_READY: "Clean & Ready",
    RoomStatus.INSPECTION_REQUIRED: "Inspection Required",
    RoomStatus.MAINTENANCE: "Under Maintenance",
    RoomStatus.OUT_OF_SERVICE: "Out of Service",
}


def status_label(status: RoomStatus | str) -> str:
    return STATUS_LABELS.get(RoomStatus(status), str(status))


def assert_transition(current: RoomStatus | str, target: RoomStatus | str) -> None:
    if not can_transition(current, target):
        cur = RoomStatus(current)
        allowed = sorted(status_label(s) for s in TRANSITIONS.get(cur, frozenset()))
        allowed_hint = f" It can move to: {', '.join(allowed)}." if allowed else ""
        raise ConflictError(
            f"Room is currently '{status_label(cur)}' and cannot be set to "
            f"'{status_label(target)}'.{allowed_hint}",
            code="invalid_room_transition",
        )


def is_allocatable(status: RoomStatus | str) -> bool:
    return RoomStatus(status) in ALLOCATABLE
