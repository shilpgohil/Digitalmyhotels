from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import require_permissions
from app.core.permissions import Permission
from app.core.tenant import TenantContext
from app.db.session import get_db
from app.schemas.platform import NotificationListOut, NotificationOut
from app.services import notifications as notifications_service

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("", response_model=NotificationListOut)
async def list_notifications(
    unread_only: bool = Query(default=False),
    category: str | None = Query(default=None),
    limit: int = Query(default=30, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    tenant: TenantContext = Depends(require_permissions(Permission.NOTIFICATIONS_VIEW)),
    db: AsyncSession = Depends(get_db),
) -> NotificationListOut:
    return await notifications_service.list_notifications(
        db, tenant, unread_only=unread_only, category=category,
        limit=limit, offset=offset,
    )


@router.post("/{notification_id}/read", response_model=NotificationOut)
async def mark_read(
    notification_id: UUID,
    tenant: TenantContext = Depends(require_permissions(Permission.NOTIFICATIONS_VIEW)),
    db: AsyncSession = Depends(get_db),
) -> NotificationOut:
    row = await notifications_service.mark_read(db, tenant, notification_id)
    out = NotificationOut.model_validate(row)
    # Read state is per-user (receipt just written) — reflect that for the caller.
    out.is_read = True
    return out


@router.post("/mark-all-read")
async def mark_all_read(
    tenant: TenantContext = Depends(require_permissions(Permission.NOTIFICATIONS_VIEW)),
    db: AsyncSession = Depends(get_db),
) -> dict:
    count = await notifications_service.mark_all_read(db, tenant)
    return {"marked_read": count}
