"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useTranslations } from "next-intl";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, MoreVertical, LogIn, XCircle, UserX } from "lucide-react";
import { PartnerHeader } from "@/components/layout/partner-header";
import { fmtApiDate, fmtINR } from "@/lib/formatting";
import { Skeleton } from "@/components/ui/skeleton";
import { PaginationFooter, paginate } from "@/components/ui/pagination-footer";
import { DataTable } from "@/components/ui/data-table";
import { FilterBar } from "@/components/ui/filter-bar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  TableCell,
  TableRow,
} from "@/components/ui/table";
import {
  BookingStatusBadge,
  PaymentStatusBadge,
} from "@/components/stay/booking-badges";
import { useApi } from "@/lib/api/use-api";
import { useAuth } from "@/lib/auth/auth-context";
import { ApiError } from "@/lib/api/client";
import { cn } from "@/lib/utils";
import type { ListOut } from "@/types/hotel";
import type { BookingOut } from "@/types/stay";
import { RequirePermission } from "@/components/auth/require-permission";
import { PERMISSIONS } from "@/lib/permissions";
import { ConfirmDialog, useConfirmDialog } from "@/components/ui/confirm-dialog";
import { useRouter, useSearchParams } from "next/navigation";

type StatusFilter = "all" | "pending" | "confirmed";

/** True when a confirmed booking's scheduled check-in has passed by ≥ 2 h.
 *  The backend sweep fires at this threshold (client 9-08 item 23). */
function isMissedArrival(b: BookingOut): boolean {
  if (b.status !== "confirmed") return false;
  const dateStr = b.check_in_date;
  const timeStr = b.check_in_time ?? "12:00";
  const scheduledMs = new Date(`${dateStr}T${timeStr}:00`).getTime();
  const nowMs = Date.now();
  return nowMs - scheduledMs >= 2 * 60 * 60 * 1000; // 2 h
}

/** `DD/MM/YYYY` plus `, HH:MM` when a time is present (no dangling comma). */
function fmtApiDateTime(date: string, time?: string | null): string {
  return time ? `${fmtApiDate(date)}, ${time}` : fmtApiDate(date);
}

function AdvanceBookingsContent() {
  const t = useTranslations("bookings");
  const tn = useTranslations("nav");
  const tc = useTranslations("common");
  const api = useApi();
  const queryClient = useQueryClient();
  const { activeHotelId } = useAuth();
  const searchParams = useSearchParams();
  const router = useRouter();
  // Persist filters in URL search params so refresh/back restores the view.
  const [search, setSearch] = useState(() => searchParams.get("q") ?? "");
  const [fromDate, setFromDate] = useState(() => searchParams.get("from") ?? "");
  const [toDate, setToDate] = useState(() => searchParams.get("to") ?? "");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [page, setPage] = useState(1);
  const [cancelTarget, setCancelTarget] = useState<BookingOut | null>(null);
  const cancelConfirm = useConfirmDialog();
  const [noShowTarget, setNoShowTarget] = useState<BookingOut | null>(null);
  const noShowConfirm = useConfirmDialog();

  // Reset pagination whenever any filter changes.
  useEffect(() => {
    setPage(1);
  }, [search, fromDate, toDate, statusFilter]);

  const filterQs =
    (search ? `&q=${encodeURIComponent(search)}` : "") +
    (fromDate ? `&from_date=${fromDate}` : "") +
    (toDate ? `&to_date=${toDate}` : "");

  // Keep URL in sync with filters so refresh/share preserves state.
  useEffect(() => {
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (fromDate) params.set("from", fromDate);
    if (toDate) params.set("to", toDate);
    const qs = params.toString();
    const url = qs ? `/advance-bookings?${qs}` : "/advance-bookings";
    router.replace(url, { scroll: false });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, fromDate, toDate]);

  // The API accepts a single status per call, so upcoming stays
  // (pending + confirmed) are fetched with two parallel queries and merged.
  const pendingBookings = useQuery({
    queryKey: ["bookings", activeHotelId, "pending", filterQs],
    queryFn: () =>
      api<ListOut<BookingOut>>(`/api/v1/bookings?status=pending&limit=100${filterQs}`),
    enabled: !!activeHotelId && statusFilter !== "confirmed",
    staleTime: 30_000,
    refetchInterval: 60_000,
  });
  const confirmedBookings = useQuery({
    queryKey: ["bookings", activeHotelId, "confirmed-list", filterQs],
    queryFn: () =>
      api<ListOut<BookingOut>>(`/api/v1/bookings?status=confirmed&limit=100${filterQs}`),
    enabled: !!activeHotelId && statusFilter !== "pending",
    staleTime: 30_000,
    refetchInterval: 60_000,
  });

  const isLoading =
    (statusFilter !== "confirmed" && pendingBookings.isLoading) ||
    (statusFilter !== "pending" && confirmedBookings.isLoading);
  const isError =
    (statusFilter !== "confirmed" && pendingBookings.isError) ||
    (statusFilter !== "pending" && confirmedBookings.isError);

  const items = useMemo(() => {
    const merged: BookingOut[] = [];
    if (statusFilter !== "confirmed" && pendingBookings.data) {
      merged.push(...pendingBookings.data.items);
    }
    if (statusFilter !== "pending" && confirmedBookings.data) {
      merged.push(...confirmedBookings.data.items);
    }
    return merged.sort((a, b) => a.check_in_date.localeCompare(b.check_in_date));
  }, [statusFilter, pendingBookings.data, confirmedBookings.data]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["bookings", activeHotelId] });
    queryClient.invalidateQueries({ queryKey: ["rooms", activeHotelId] });
    queryClient.invalidateQueries({ queryKey: ["room-status-summary", activeHotelId] });
    queryClient.invalidateQueries({ queryKey: ["current-guests", activeHotelId] });
  };

  const cancelMutation = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      api<BookingOut>(`/api/v1/bookings/${id}/cancel`, {
        method: "POST",
        body: { reason },
      }),
    onSuccess: () => {
      toast.success(t("bookingCancelled"));
      invalidate();
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : tc("error")),
  });

  const noShowMutation = useMutation({
    mutationFn: (id: string) =>
      api<BookingOut>(`/api/v1/bookings/${id}/no-show`, { method: "POST" }),
    onSuccess: () => {
      toast.success(t("markedNoShow"));
      setNoShowTarget(null);
      invalidate();
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : tc("error")),
  });

  const statusChips: { value: StatusFilter; label: string }[] = [
    { value: "all", label: t("statusAll") },
    { value: "pending", label: t("status_pending") },
    { value: "confirmed", label: t("status_confirmed") },
  ];

  return (
    <>
      <PartnerHeader title={t("advanceBookingsTitle")} subtitle={tn("frontDesk")} />
      <main className="flex-1 overflow-y-auto p-4 sm:p-6">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <FilterBar
            searchValue={search}
            onSearchChange={setSearch}
            searchPlaceholder={t("searchPlaceholder")}
            fromDate={fromDate}
            onFromDateChange={setFromDate}
            fromLabel={t("checkinDate")}
            toDate={toDate}
            onToDateChange={setToDate}
            toLabel={t("checkoutDate")}
            hasActiveFilters={!!(search || fromDate || toDate)}
            onClear={() => { setSearch(""); setFromDate(""); setToDate(""); }}
          />
          <button
            type="button"
            onClick={() => router.push("/advance-booking")}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-gold-500 px-2.5 text-sm font-medium text-navy-900 hover:bg-gold-400"
          >
            <Plus className="size-4" aria-hidden />
            {t("newBooking")}
          </button>

          {/* No-show confirmation dialog — describes consequences (room freed,
              booking closed, cannot be undone without manual data correction). */}
          <ConfirmDialog
            open={noShowConfirm.open}
            title={t("markNoShow")}
            message={
              noShowTarget
                ? `${noShowTarget.booking_number} — ${noShowTarget.primary_guest_name ?? ""}\n\n${t("noShowWarning")}`
                : undefined
            }
            confirmLabel={t("confirmNoShow")}
            confirmVariant="destructive"
            isPending={noShowMutation.isPending}
            onConfirm={() => {
              if (noShowTarget) {
                noShowMutation.mutate(noShowTarget.id);
                noShowConfirm.hide();
              }
            }}
            onCancel={() => {
              noShowConfirm.hide();
              setNoShowTarget(null);
            }}
          />

          <ConfirmDialog
            open={cancelConfirm.open}
            title={t("cancelBooking")}
            message={cancelTarget ? `${cancelTarget.booking_number} — ${cancelTarget.primary_guest_name ?? ""}` : undefined}
            requireText
            textLabel={t("cancelReason")}
            textPlaceholder={t("cancelReason")}
            confirmLabel={t("cancelBooking")}
            confirmVariant="destructive"
            isPending={cancelMutation.isPending}
            onConfirm={(reason) => {
              if (cancelTarget) {
                cancelMutation.mutate({ id: cancelTarget.id, reason });
                cancelConfirm.hide();
                setCancelTarget(null);
              }
            }}
            onCancel={() => {
              cancelConfirm.hide();
              setCancelTarget(null);
            }}
          />
        </div>

        {/* Status filter chips */}
        <div className="mb-4 flex flex-wrap gap-2">
          {statusChips.map((chip) => (
            <button
              key={chip.value}
              type="button"
              onClick={() => setStatusFilter(chip.value)}
              className={cn(
                "inline-flex items-center rounded-full border px-3 py-1.5 text-sm transition-colors",
                statusFilter === chip.value
                  ? "border-navy-900 bg-navy-900 font-medium text-white"
                  : "border-border text-muted-foreground hover:border-navy-900 hover:text-navy-900",
              )}
            >
              {chip.label}
            </button>
          ))}
        </div>

        <DataTable
          darkHeader
          isLoading={isLoading}
          isError={isError}
          onRetry={() => { pendingBookings.refetch(); confirmedBookings.refetch(); }}
          isEmpty={!isLoading && !isError && items.length === 0}
          emptyTitle={t("noBookings")}
          columns={[
            t("bookingNumber"), t("guest"), t("roomsCol"),
            t("dates"), t("total"), t("statusCol"), t("payment"),
            tc("actions"),
          ]}
          rightAlignCols={[7]}
        >
          {/* No <TableBody> wrapper — DataTable provides it (nested tbody breaks layout) */}
          {!isLoading && !isError &&
              paginate(items, page, 10).map((booking) => (
                  <TableRow key={booking.id}>
                    <TableCell className="font-medium">{booking.booking_number}</TableCell>
                    <TableCell>{booking.primary_guest_name ?? "—"}</TableCell>
                    <TableCell>
                      {booking.rooms
                        .filter((r) => r.is_current)
                        .map((r) => r.room_number)
                        .join(", ")}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs">
                      <span className="whitespace-nowrap">{fmtApiDateTime(booking.check_in_date, booking.check_in_time)}</span>
                      {" → "}
                      <span className="whitespace-nowrap">{fmtApiDateTime(booking.check_out_date, booking.check_out_time)}</span>
                    </TableCell>
                    <TableCell className="tabular-nums">{fmtINR(booking.total_amount)}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <BookingStatusBadge status={booking.status} />
                        {/* Missed arrival: confirmed booking past check-in by ≥ 2h (item 23) */}
                        {isMissedArrival(booking) && (
                          <span className="inline-flex items-center rounded-full bg-warning-bg px-2 py-0.5 text-micro font-semibold text-warning">
                            Missed arrival
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <PaymentStatusBadge status={booking.payment_status} />
                    </TableCell>
                    <TableCell className="text-right">
                      {(booking.status === "pending" || booking.status === "confirmed") && (
                        <DropdownMenu>
                          <DropdownMenuTrigger
                            className="inline-flex size-8 items-center justify-center rounded-md hover:bg-muted"
                            aria-label={tc("actions")}
                          >
                            <MoreVertical className="size-4" aria-hidden />
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {booking.status === "confirmed" && (
                              <DropdownMenuItem
                                onClick={() => router.push(`/checkin?booking=${booking.id}`)}
                              >
                                <LogIn className="size-4" aria-hidden />
                                {t("checkInAction")}
                              </DropdownMenuItem>
                            )}
                            {booking.status === "confirmed" && (
                              <DropdownMenuItem
                                onClick={() => {
                                  setNoShowTarget(booking);
                                  noShowConfirm.show();
                                }}
                              >
                                <UserX className="size-4" aria-hidden />
                                {t("markNoShow")}
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              variant="destructive"
                              onClick={() => {
                                setCancelTarget(booking);
                                cancelConfirm.show();
                              }}
                            >
                              <XCircle className="size-4" aria-hidden />
                              {t("cancelBooking")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
        </DataTable>
        {!isLoading && !isError && items.length > 0 && (
          <PaginationFooter
            page={page}
            total={items.length}
            pageSize={10}
            onPageChange={setPage}
          />
        )}
      </main>
    </>
  );
}

export default function AdvanceBookingsPage() {
  return (
    <RequirePermission permission={PERMISSIONS.bookingsView}>
      {/* Suspense is required by Next.js App Router for useSearchParams() */}
      <Suspense fallback={<div className="flex-1 p-6"><Skeleton className="h-10 w-full" /></div>}>
        <AdvanceBookingsContent />
      </Suspense>
    </RequirePermission>
  );
}
